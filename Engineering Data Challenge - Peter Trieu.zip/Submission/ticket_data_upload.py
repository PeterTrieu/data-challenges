# Peter Trieu
# Aginic Engineering Data Challenge Part 2

# Importing modules
import json
import sqlite3
from datetime import datetime

# Establish connection
connection = sqlite3.connect('db.sqlite')
cursor = connection.cursor()
#print("Successfully Connected to SQLite")

# Create ticket_data Table
create_tickets_table_query = '''CREATE TABLE IF NOT EXISTS tickets(
                                ticket_id SMALLINT NOT NULL,
                                performer_id INT NOT NULL,
                                performer_type VARCHAR(8) NOT NULL,
                                note_id INT NOT NULL,
                                note_type TEXT NOT NULL,
                                initiated_at DATETIME NOT NULL,
                                PRIMARY KEY(ticket_id,note_id)
                                );'''
cursor.execute(create_tickets_table_query)
#print("Successfully Created tickets Table on SQLite")

# Create ticket_info_table Table
create_ticket_info_table_query = '''CREATE TABLE IF NOT EXISTS ticket_info(
                                ticket_info_id INTEGER PRIMARY KEY AUTOINCREMENT,
                                ticket_no SMALLINT NOT NULL,
                                shipping_address TEXT NOT NULL,
                                shipment_date DATETIME NOT NULL,
                                category VARCHAR(15) NOT NULL,
                                contacted_customer VARCHAR(5) NOT NULL,
                                issue_type VARCHAR(29) NOT NULL,
                                source TINYINT NOT NULL,
                                priority TINYINT NOT NULL,
                                activity_group VARCHAR(20) NOT NULL,
                                agent_id INT NOT NULL,
                                requester INT NOT NULL,
                                product VARCHAR(16) NOT NULL,
                                FOREIGN KEY(ticket_no) REFERENCES ticket_data(ticket_id)
                                );'''
cursor.execute(create_ticket_info_table_query)
#print("Successfully Created ticket_info Table on SQLite")

# Create ticket_activity_table Table
create_ticket_activity_table_query = '''CREATE TABLE IF NOT EXISTS ticket_activity(
                                ticket_activity_id INTEGER PRIMARY KEY AUTOINCREMENT,
                                ticket_no SMALLINT NOT NULL,
                                status VARCHAR(23) NOT NULL,
                                performed_at DATETIME NOT NULL,
                                FOREIGN KEY(ticket_no) REFERENCES ticket_data(ticket_id)
                                );'''
cursor.execute(create_ticket_activity_table_query)
#print("Successfully Created ticket_activity Table on SQLite")

# Import JSON data from file name
json_array = json.load(open('activities.json'))

# Remove the metadata section as it isn't required
json_array = json_array["activities_data"]

# Set up initial parameters
new_ticket = True
current_ticket = 0
new_activity_info = True


# Uploading JSON data to SQLite
for json_object in json_array:
    json_activity = json_object["activity"]
    # Check if ticket id is unique
    if(json_object["ticket_id"] != current_ticket):
        new_ticket = True
        new_activity_info = True
        current_ticket = json_object["ticket_id"]
    else:
        new_ticket = False
    # If ticket id is unique it must be the first JSON object for that ticket and will contain a note for the activity
    if(new_ticket == True):
        # SQLite Query
        sqlite_insert_with_param = """INSERT INTO tickets
                                  (ticket_id, performer_id, performer_type, note_id, note_type, initiated_at) 
                                  VALUES (?, ?, ?, ?, ?, ?);"""
        # Rearranging dates to be in correct format for the next task using JULIANDAY
        date_time = datetime.strptime(json_object["performed_at"],"%d-%m-%Y %H:%M:%S")
        # Storing JSON object data as a tuple
        data_tuple = (json_object["ticket_id"], json_object["performer_id"], json_object["performer_type"], json_activity["note"]["id"],json_activity["note"]["type"], date_time)
        # Upload the data to SQLite
        cursor.execute(sqlite_insert_with_param, data_tuple)
        # Commit changes
        connection.commit()
        #print("JSON Ticket Object inserted successfully into SQLite Table ticket_data")
    # Else ticket id is not unique it must be the second or late JSON object for that ticket and will contain info and data for the activities
    else:
        # If ticket information has been uploaded to SQLite
        if(new_activity_info == True):
            sqlite_insert_with_param = """INSERT INTO ticket_info
                                      (ticket_info_id, ticket_no, shipping_address, shipment_date, category, contacted_customer,issue_type,source,priority,activity_group,agent_id,requester,product) 
                                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);"""
            # Storing JSON object data as a tuple
            data_tuple = (None,json_object["ticket_id"], json_activity["shipping_address"], json_activity["shipment_date"], json_activity["category"],
                        json_activity["contacted_customer"], json_activity["issue_type"], json_activity["source"], json_activity["priority"],
                        json_activity["group"], json_activity["agent_id"], json_activity["requester"], json_activity["product"])
            # Upload the data to SQLite
            cursor.execute(sqlite_insert_with_param, data_tuple)
            # Commit changes
            connection.commit()
            #print("JSON Ticket Info Object inserted successfully into SQLite Table ticket_info")
            new_activity_info = False
            # Upload ticket activity
            sqlite_insert_with_param = """INSERT INTO ticket_activity
                                      (ticket_activity_id, ticket_no, status, performed_at) 
                                      VALUES (?, ?, ?, ?);"""
            # Rearranging dates to be in correct format for the next task using JULIANDAY
            date_time = datetime.strptime(json_object["performed_at"],"%d-%m-%Y %H:%M:%S")
            # Storing JSON object data as a tuple
            data_tuple = (None, json_object["ticket_id"], json_activity["status"], date_time)
            # Upload the data to SQLite
            cursor.execute(sqlite_insert_with_param, data_tuple)
            # Commit changes
            connection.commit()
            #print("JSON Ticket Activity Object inserted successfully into SQLite Table ticket_activity")
        # Else upload ticket activity without ticket information
        else:
            sqlite_insert_with_param = """INSERT INTO ticket_activity
                                      (ticket_activity_id, ticket_no, status, performed_at) 
                                      VALUES (?, ?, ?, ?);"""
            # Rearranging dates to be in correct format for the next task using JULIANDAY
            date_time = datetime.strptime(json_object["performed_at"],"%d-%m-%Y %H:%M:%S")
            # Storing JSON object data as a tuple
            data_tuple = (None, json_object["ticket_id"], json_activity["status"], date_time)
            # Upload the data to SQLite
            cursor.execute(sqlite_insert_with_param, data_tuple)
            # Commit changes
            connection.commit()
            #print("JSON Ticket Activity Object inserted successfully into SQLite Table ticket_activity")

# Commit changes
connection.commit()
#print("Successfully Committed to SQLite")

# Close Connection
connection.close()
#print("Successfully Disconnected to SQLite")
