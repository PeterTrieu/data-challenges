-- Peter Trieu --
-- Aginic Engineering Data Challenge Part 3 --

-- Retrieve time since the ticket was created --
CREATE VIEW [time_since_start] AS
SELECT t.ticket_id, t.initiated_at, ta.status, ta.performed_at, 
    CAST((JULIANDAY(ta.performed_at) - JULIANDAY(t.initiated_at)) * 24*60 AS INT) as time_spent -- MINUTES
FROM 
    tickets t
JOIN 
    ticket_activity ta
ON 
    t.ticket_id = ta.ticket_no;

-- Create views for each status --
CREATE VIEW [open_ticket_time] AS
SELECT 
    ticket_id,
    performed_at,
    time_spent
FROM 
    time_since_start
WHERE
    status = "Open";
  
CREATE VIEW [pending_ticket_time] AS
SELECT 
    ticket_id, 
    performed_at,
    time_spent
FROM 
    time_since_start
WHERE
    status = "Pending";
    
CREATE VIEW [waiting_ticket_time] AS
SELECT 
    ticket_id, 
    performed_at,
    time_spent
FROM 
    time_since_start
WHERE
    status = "Waiting for Customer"
OR
    status = "Waiting for Third Party";

CREATE VIEW [completed_ticket_time] AS
SELECT 
    ticket_id, 
    performed_at,
    time_spent
FROM 
    time_since_start
WHERE
    status = "Resolved"
OR
    status = "Closed";
    
-- Generating attributes for each ticket for the challange -- 
-- NOTE : ALL THESE TIMES ARE IN MINUTES --
SELECT
    o.ticket_id,
    IFNULL(IFNULL(p.time_spent-o.time_spent,CAST((JULIANDAY(datetime('now')) - JULIANDAY(o.performed_at)) * 24*60 AS INT)),0) as time_spent_open, 
    IFNULL(IFNULL(c.time_spent-w.time_spent,CAST((JULIANDAY(datetime('now')) - JULIANDAY(w.performed_at)) * 24*60 AS INT)),0) as time_spent_waiting_on_customer, 
    IFNULL(IFNULL(w.time_spent-p.time_spent,CAST((JULIANDAY(datetime('now')) - JULIANDAY(p.performed_at)) * 24*60 AS INT)),0) as time_spent_waiting_for_response, 
    IFNULL(IFNULL(c.time_spent-o.time_spent,CAST((JULIANDAY(datetime('now')) - JULIANDAY(o.performed_at)) * 24*60 AS INT)),0) as time_till_resolution,
    IFNULL(IFNULL(w.time_spent-o.time_spent,CAST((JULIANDAY(datetime('now')) - JULIANDAY(p.performed_at)) * 24*60 AS INT)),0) as time_to_first_response
FROM
    open_ticket_time o 
LEFT JOIN
    pending_ticket_time p
ON
    o.ticket_id = p.ticket_id
LEFT JOIN
    waiting_ticket_time w
ON
    o.ticket_id = w.ticket_id
LEFT JOIN
    completed_ticket_time c
ON
    o.ticket_id = c.ticket_id