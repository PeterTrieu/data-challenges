Assumptions that have been made for this Data Challenge
- Freshdesk provides a Helpdesk system for mobile companies such as Telstra, Optus, Vodaphone, etc.
- Only one employee/agent/performer can be assigned to a ticket
- Employee/agent/performer can also raise internal tickets
- A ticket will be the following order:
-- Note -> Open -> Pending -> Waiting for Customer/Waiting for Third Party -> Closed
- Will assume that there are tickets that are still open/pending/waiting for customer/waiting for third party

To run the command line script called run_all_tasks.cmd, open command prompt and cd to the directory that contains all the files and then enter the command run_all_tasks.cmd
To rerun the command line script called run_all_tasks.cmd, make sure to delete the db.sqlite every rerun