# Peter Trieu
# Aginic Engineering Data Challenge Part 1

# Example command prompt
# ticket_gen.py -n 1000 -o activities.json

# Importing Modules
from random import randrange
from datetime import datetime
from datetime import timedelta
from random import randint
from random_address import random_address #https://pypi.org/project/random-address/
import random
import json
import getopt
import sys

# Function to retrieve a random date based on the start and end times
def random_date(start, end):
    delta = end - start
    delta_sec = delta.total_seconds()
    random_second = randrange(int(delta_sec))
    return start + timedelta(seconds=random_second)


# Function to generate random note
def random_note(json_data_activities,performed_at,ticket_id,performer_type,performer_id):
    # Assumed there are 1000000000 note id and that the possibility of it being the same note id is very low
    id = randint(1,1000000000)

    # Assumed there are 4 types of notes where 1=Inline, 2=Ticket, 3=Contact, 4=Company
    type = random.choice([1,2,3,4])

    # Create JSON Data Note
    json_data_note = {"id" : id,
                      "type" : type
                      }
    # Create JSON Activity Data
    json_data_activity = {"note" : json_data_note}

    #Append data to JSON Activities Data
    json_data_activities.append({"performed_at" : performed_at.strftime("%d-%m-%Y %H:%M:%S"),
                                 "ticket_id" : ticket_id,
                                 "performer_type" : performer_type,
                                 "performer_id" : performer_id,
                                 "activity" : json_data_activity
                                 })

    
# Function to generate random activity status
def random_activity(json_data_activities,performed_at,ticket_id,performer_type,performer_id,status,shipping_address,
                                shipment_date,category,contacted_customer,issue_type,source,priority,group,agent_id,requester,product):
        # There are 6 status for the helpdesk system as defined in challenge
        status = status
        # Create JSON Activity Data
        json_data_activity = { "shipping_address" : shipping_address,
                               "shipment_date" : shipment_date,
                               "category" : category,
                               "contacted_customer" : contacted_customer,
                               "issue_type" : issue_type,
                               "source" : source,
                               "status" : status,
                               "priority" : priority,
                               "group" : group,
                               "agent_id" : agent_id,
                               "requester" : requester,
                               "product" : product
                               }
        #Append data to JSON Activities Data
        json_data_activities.append({"performed_at" : performed_at.strftime("%d-%m-%Y %H:%M:%S"),
                                     "ticket_id" : ticket_id,
                                     "performer_type" : performer_type,
                                     "performer_id" : performer_id,
                                     "activity" : json_data_activity
                                     })

# Date Assumptions
# - Time format is in dd-mm-yyyy hh:mm:ss and ignoring +0000
# - Data cannot be in the future
# - Ignoring Leap Years
current_date = datetime.now()-timedelta(days=16)
date_end = current_date
date_start = current_date-timedelta(days=365)

def ticket_gen():
    # Number of tickets    
    tickets = 0
    
    # File Name
    file_name = "empty.json"
  
    argv = sys.argv[1:]
  
    try:
        opts, args = getopt.getopt(argv, "n:o:")
      
    except:
        print("Error")
  
    for opt, arg in opts:
        if opt in ['-n']:
            tickets = int(arg)
        elif opt in ['-o']:
            file_name = arg
    
    # JSON File Setup
    json_data = {}
    json_data_activities = []
    json_data['metadata'] = {"start_at" : date_start.strftime("%d-%m-%Y %H:%M:%S"), "end_at" : date_end.strftime("%d-%m-%Y %H:%M:%S"),"activities_count" : tickets}

    for x in range(tickets):       
        # Performed at
        performed_at = random_date(date_start, date_end)
        
        # Generate unique ticket ID
        # Note there is probably a more efficient way of doing this
        unique = False
        ticket_id = randint(1,9999)
        while unique == False and x!=0:
            # Assumed there is a ticket id from 1-9999
            ticket_id = randint(1,9999)
            ticket_list = [0]*len(json_data_activities)
            for y in range(len(json_data_activities)):
                if(ticket_id != json_data_activities[y]['ticket_id']):
                    ticket_list[y] = 0
                else:
                    ticket_list[y] = 1
            if(1 not in ticket_list):
                unique = True
                
        # Assumed there is only two types of performers(people who requested the ticket) for the helpdesk system which are the users from the mobile companies or the employees that works at Freshdesk
        performer_type = random.choice(["user", "employee"])

        # Assumed there are 200000 performer which are the employee that was assigned to the ticket
        performer_id = randint(1,200000)
        
        # Generate note
        random_note(json_data_activities,performed_at,ticket_id,performer_type,performer_id)
        
        # Generate activity amount
        random_activity_amount = randint(1,4)

        # Assume there are either addresses or no address
        shipping_address_NA = random.choice([True,False])
        if shipping_address_NA==True:
            # Retreving random addresses from America, California
            shipping_address = random_address.real_random_address_by_state('CA')["address1"]
        else:
            # No address
            shipping_address = "N/A"
            
        # Assume there yes or no to shipping date
        shipment_date_NA = random.choice([True,False])
        if shipment_date_NA==True:
            # Retrieve random shipment date
            # Assume that shipment date is either the same performed_at date or after the performed_at date
            shipment_date = random_date(performed_at, performed_at+timedelta(days=3)).strftime("%d %b,%Y")
        else:
            shipment_date = "N/A"

        # Assumed there are only three types of categories for the helpdesk system
        category = random.choice(["home internet", "phone", "tablet", "mobile internet"])

        # Assumed contacted customer is random
        contacted_customer = random.choice([True, False])

        # Assumed there are 8 type of issue type based on a typical helpdesk system for mobile providers
        issue_type = random.choice(["change", "IT Help", "incident", "new feature", "problem", "service request", "service request with approval","support"])
        
        # Assumed there are 10 mobile providers that uses the helpdesk system
        source = randint(1,10)

        # Assumed there are 4 priority where 1 = Highest Priority and 4 = Lowest
        priority = randint(1,4)

        # Assumed there are 9 groups for the helpdesk system
        group = random.choice(["refund","payment","technical support","customer service","sales","business support","moving/disconnecting","internal","other"])
        
        # Agents are the performers based on the data
        agent_id = performer_id

        # Assumed there are 200000 requesters which is the person that requested the ticket which could be a user or employee
        requester = randint(1,200000)

        # Assumed there are 7 types of products
        product = random.choice(["mobile","tablet","nbn","4g home internet","5g home internet","4G","5G"])

        # Randomise activity
        for z in range(random_activity_amount):
            if(z == 0):
                performed_at = random_date(performed_at, performed_at+timedelta(days=1))
                random_activity(json_data_activities,performed_at,ticket_id,performer_type,performer_id,"Open",shipping_address,
                                shipment_date,category,contacted_customer,issue_type,source,priority,group,agent_id,requester,product)
            elif(z == 1):
                performed_at = random_date(performed_at, performed_at+timedelta(days=3))
                random_activity(json_data_activities,performed_at,ticket_id,performer_type,performer_id,"Pending",shipping_address,
                                shipment_date,category,contacted_customer,issue_type,source,priority,group,agent_id,requester,product)
            elif(z == 2):
                performed_at = random_date(performed_at, performed_at+timedelta(days=5))
                rand_choice = random.choice(["Waiting for Customer","Waiting for Third Party"])
                random_activity(json_data_activities,performed_at,ticket_id,performer_type,performer_id,rand_choice,shipping_address,
                                shipment_date,category,contacted_customer,issue_type,source,priority,group,agent_id,requester,product)
            elif(z == 3):
                performed_at = random_date(performed_at, performed_at+timedelta(days=5))
                rand_choice = random.choice(["Resolved","Closed"])
                random_activity(json_data_activities,performed_at,ticket_id,performer_type,performer_id,rand_choice,shipping_address,
                                shipment_date,category,contacted_customer,issue_type,source,priority,group,agent_id,requester,product)
        
    # Convert everything to a JSON Object
    json_data['activities_data'] = json_data_activities
    json_object = json.dumps(json_data)
    
    # Write JSON file
    with open(file_name, "w") as outfile:
        outfile.write(json_object)

ticket_gen()    

